﻿using Microsoft.AspNetCore.Mvc;

namespace BlaqJzure.Web.Controllers
{
    public class CheckOutController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
